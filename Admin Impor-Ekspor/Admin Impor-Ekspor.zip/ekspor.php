<?php
/*
    Hak Cipta © 2024 Mochamad Naufal Shofy
    Web ini telah dilesensikan
    Repository GitHub: https://github.com/nopalsh/3-web-projects
*/
require_once "koneksi.php";
session_start();
if (!isset($_SESSION["id_pengguna"])) {
    header("Location: login.php");
    exit();
}
$id_pengguna = $_SESSION["id_pengguna"];
$negara = isset($_SESSION["negara"]) ? $_SESSION["negara"] : "";
$filterStatusEkspor = isset($_GET["statusFilterEkspor"]) ? $_GET["statusFilterEkspor"] : "";
$filterCountryEkspor = isset($_GET["countryFilterEkspor"]) ? $_GET["countryFilterEkspor"] : "";
$filterTypeEkspor = isset($_GET["typeFilterEkspor"]) ? $_GET["typeFilterEkspor"] : "";
$filterYearEkspor = isset($_GET["yearFilterEkspor"]) ? $_GET["yearFilterEkspor"] : "";
$filterMonthEkspor = isset($_GET["monthFilterEkspor"]) ? $_GET["monthFilterEkspor"] : "";
$filterIdEkspor = isset($_GET["idEksporFilterEkspor"]) ? $_GET["idEksporFilterEkspor"] : "";

$sql = "SELECT ekspor_barang.id_ekspor,
        (SELECT negara FROM pengguna WHERE id_pengguna = ekspor_barang.negara_penerima) AS negara_penerima,
        detail_barang.tipe_barang, detail_barang.nama_barang,
        ekspor_barang.status, ekspor_barang.tanggal_ekspor
        FROM ekspor_barang
        INNER JOIN detail_barang ON ekspor_barang.id_barang = detail_barang.id_barang
        WHERE ekspor_barang.id_pengguna = $id_pengguna";

if (!empty($filterStatusEkspor)) {
    $sql .= " AND ekspor_barang.status = '$filterStatusEkspor'";
}
if (!empty($filterCountryEkspor)) {
    $sql .= " AND ekspor_barang.negara_penerima = '$filterCountryEkspor'";
}
if (!empty($filterTypeEkspor)) {
    $sql .= " AND detail_barang.tipe_barang = '$filterTypeEkspor'";
}
if (!empty($filterYearEkspor)) {
    $sql .= " AND YEAR(ekspor_barang.tanggal_ekspor) = '$filterYearEkspor'";
}
if (!empty($filterMonthEkspor)) {
    $sql .= " AND MONTH(ekspor_barang.tanggal_ekspor) = '$filterMonthEkspor'";
}
if (!empty($filterIdEkspor)) {
    $sql .= " AND ekspor_barang.id_ekspor = '$filterIdEkspor'";
}
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en" style="font-family: Poppins, sans-serif;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ekspedisi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/Navbar-Right-Links-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body id="page-top">
  <div id="wrapper" style="font-family: Poppins, sans-serif;">
    <div class="d-flex flex-column" id="content-wrapper" style="background: #f8f9fb;">
      <div id="wrapper">
        <nav class="navbar align-items-start sidebar accordion" style="background: #fff; border-right: 1px solid #eeeeee;">
          <div class="container-fluid d-flex flex-column p-0">
            <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
              <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-truck-loading" style="color: #142fb3;"></i>
              </div>
              <div class="sidebar-brand-text mx-3">
                <span style="color: #000000;">EKSPEDISI</span>
              </div>
            </a>
            <hr class="sidebar-divider my-0" />
            <ul id="accordionSidebar" class="navbar-nav text-light">
              <li class="nav-item">
                <a class="nav-link active" href="index.php">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -32 576 576" width="1em" height="1em" fill="currentColor" style="color: #6a6b83; position: relative; margin-top: -4px; margin-right: 8px;">
                    <path d="M511.8 287.6L512.5 447.7C512.5 450.5 512.3 453.1 512 455.8V472C512 494.1 494.1 512 472 512H456C454.9 512 453.8 511.1 452.7 511.9C451.3 511.1 449.9 512 448.5 512H392C369.9 512 352 494.1 352 472V384C352 366.3 337.7 352 320 352H256C238.3 352 224 366.3 224 384V472C224 494.1 206.1 512 184 512H128.1C126.6 512 125.1 511.9 123.6 511.8C122.4 511.9 121.2 512 120 512H104C81.91 512 64 494.1 64 472V360C64 359.1 64.03 358.1 64.09 357.2V287.6H32.05C14.02 287.6 0 273.5 0 255.5C0 246.5 3.004 238.5 10.01 231.5L266.4 8.016C273.4 1.002 281.4 0 288.4 0C295.4 0 303.4 2.004 309.5 7.014L416 100.7V64C416 46.33 430.3 32 448 32H480C497.7 32 512 46.33 512 64V185L564.8 231.5C572.8 238.5 576.9 246.5 575.8 255.5C575.8 273.5 560.8 287.6 543.8 287.6L511.8 287.6z"></path>
                  </svg>
                  <span style="color: #6a6b83;">
                    <span style="font-weight: normal !important;">Beranda</span>
                  </span>
                </a>
                <a class="nav-link active" href="impor.php">
                  <svg class="bi bi-box-arrow-in-down" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" style="color: #3f4d95; position: relative; margin-top: -8px; margin-right: 8px;">
                    <path fill-rule="evenodd" d="M3.5 6a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 1 0-1h2A1.5 1.5 0 0 1 14 6.5v8a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 14.5v-8A1.5 1.5 0 0 1 3.5 5h2a.5.5 0 0 1 0 1h-2z"></path>
                    <path fill-rule="evenodd" d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
                  </svg>
                  <span style="color: #6a6b83;">
                    <span style="font-weight: normal !important;">Data Impor</span>
                  </span>
                </a>
                <a class="nav-link active" href="ekspor.php" style="background: #dadcef;border-width: 10px;border-color: rgb(0,0,0);border-left: 5px solid #142fb3;">
                  <svg class="bi bi-box-arrow-in-up" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" style="color: #3f4d95; position: relative; margin-top: 0; margin-right: 8px;">
                    <path fill-rule="evenodd" d="M3.5 10a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 0 0 1h2A1.5 1.5 0 0 0 14 9.5v-8A1.5 1.5 0 0 0 12.5 0h-9A1.5 1.5 0 0 0 2 1.5v8A1.5 1.5 0 0 0 3.5 11h2a.5.5 0 0 0 0-1h-2z"></path>
                    <path fill-rule="evenodd" d="M7.646 4.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707V14.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708l3-3z"></path>
                  </svg>
                  <span style="color: #3f4d95;">Data Ekspor</span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
        <div class="container-fluid" style="padding: 0; margin: 0;">
          <nav class="navbar navbar-expand mb-4 topbar static-top navbar-light navbar-dark"
            style="background: #142fb3; border-bottom-width: 1px; border-bottom-style: solid;
            border-bottom-color: #eeeeee;">
            <div class="container-fluid">
              <form method="GET" action="" class="mb-4">
                <div class="row">
                  <div class="col-md-10 d-flex align-items-center" style="padding-top: 5%;">
                    <label for="idEksporFilterEkspor" class="form-label mb-0 me-2"
                      style="width: 180px; color: #fff">Cari ID Ekspor:</label>
                    <div class="input-group flex-grow-1">
                      <input type="text" class="form-control rounded-pill" id="idEksporFilterEkspor"
                        name="idEksporFilterEkspor" placeholder="Masukkan ID Ekspor"
                        style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
                      <button type="submit" class="btn btn-primary rounded-pill"
                        style="border-top-left-radius: 0; border-bottom-left-radius: 0; margin-left: 10px;">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </form>
              <ul class="navbar-nav flex-nowrap ms-auto" style="margin: 0;">
                <div class="d-none d-sm-block topbar-divider"></div>
                <li class="nav-item dropdown no-arrow">
                  <div class="nav-item dropdown no-arrow">
                    <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#"
                      style="color: white;">
                      <?php
                      $id_pengguna = $_SESSION['id_pengguna'];
                      $query = "SELECT negara FROM pengguna WHERE id_pengguna = $id_pengguna";
                      $result = $conn->query($query);
                      if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          $negara = $row['negara'];
                          echo "<span class='d-none d-lg-inline me-2 small'>$negara</span>";
                        }
                      }
                      ?>
                      <img class="border rounded-circle img-profile"
                        src="https://t3.ftcdn.net/jpg/05/14/18/46/360_F_514184651_W5rVCabKKRH6H3mVb62jYWfuXio8c8si.jpg" />
                    </a>
                    <div class="dropdown-menu dropdown-menu-end animated--grow-in">
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="logout.php" style="color: black;">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>
                        Keluar
                      </a>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </nav>
          <div class="container-fluid">
            <div class="card">
                <div class="card-header py-2 bg-white">
                    <h5 class="m-0">
                        <button class="btn btn-link text-dark" type="button" data-bs-toggle="collapse" data-bs-target="#filterCollapse" aria-expanded="true" aria-controls="filterCollapse">
						    <svg class="bi bi-filter" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" style="">
						    </svg>Filter Data
						</button>
                    </h5>
                </div>
                <div class="collapse show" id="filterCollapse">
                    <div class="card-body text-dark">
                        <form method="GET" action="" class="mb-1 text-dark">
                            <div class="row">
                                <div class="col-md-2">
                                    <label for="statusFilterEkspor" class="form-label">Filter Status:</label>
                                    <select class="form-select" id="statusFilterEkspor" name="statusFilterEkspor">
									<option value="">Semua</option>
									<?php
                                    $statusQuery = "SELECT DISTINCT status FROM ekspor_barang";
                                    $statusResult = $conn->query($statusQuery);
                                    if ($statusResult->num_rows > 0) {
                                        while ($row = $statusResult->fetch_assoc()) {
                                                $status = $row['status'];
                                                echo "<option value='$status'>$status</option>";
                                            }
                                        }
                                    ?>
									</select>
                            </div>
                            <div class="col-md-2">
							    <label for="countryFilterEkspor" class="form-label">Filter Negara:</label>
								    <select class="form-select" id="countryFilterEkspor" name="countryFilterEkspor">
										<option value="">Semua</option>
											<?php
											$countryQuery = "SELECT DISTINCT ekspor_barang.negara_penerima FROM ekspor_barang";
											$countryResult = $conn->query($countryQuery);
											if ($countryResult->num_rows > 0) {
												while ($row = $countryResult->fetch_assoc()) {
													    $country = $row['negara_penerima'];
															$countryValueQuery = "SELECT negara FROM pengguna WHERE id_pengguna = '$country'";
															$countryValueResult = $conn->query($countryValueQuery);
															if ($countryValueResult->num_rows > 0) {
																$countryValueRow = $countryValueResult->fetch_assoc();
																$countryValue = $countryValueRow['negara'];
															} else {
																$countryValue = $country;
															}
															echo "<option value='$country'>$countryValue</option>";
														}
													}
												?>
									</select>
							</div>
                            <div class="col-md-2">
                                <label for="typeFilterEkspor" class="form-label">Filter Tipe Barang:</label>
                                <select class="form-select" id="typeFilterEkspor" name="typeFilterEkspor">
								<option value="">Semua</option>
								<?php
                                    $typeQuery = "SELECT DISTINCT tipe_barang FROM detail_barang";
                                    $typeResult = $conn->query($typeQuery);
                                    if ($typeResult->num_rows > 0) {
                                        while ($row = $typeResult->fetch_assoc()) {
                                                $type = $row['tipe_barang'];
                                                echo "<option value='$type'>$type</option>";
                                        }
                                    }
                                ?>
								</select>
							</div>
							<div class="col-md-2">
                                <label for="monthFilterEkspor" class="form-label">Filter Bulan:</label>
                                <select class="form-select" id="monthFilterEkspor" name="monthFilterEkspor">
									<option value="">Semua</option>
									<option value="01">Januari</option>
									<option value="02">Februari</option>
									<option value="03">Maret</option>
									<option value="04">April</option>
									<option value="05">Mei</option>
									<option value="06">Juni</option>
									<option value="07">Juli</option>
									<option value="08">Agustus</option>
									<option value="09">September</option>
									<option value="10">Oktober</option>
									<option value="11">November</option>
									<option value="12">Desember</option>
								</select>
                            </div>
                                <div class="col-md-2">
                                    <label for="yearFilterEkspor" class="form-label">Filter Tahun:</label>
                                    <input type="number" class="form-control" id="yearFilterEkspor" name="yearFilterEkspor" min="2000" max="2024" placeholder="Masukan Tahun">
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary-submit">Submit</button>
                                </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
            <br/>
                <div class="card">
                    <div class="card-header py-3 bg-white">
                        <b><h5 class="m-0 text-dark">
                        <div class="float-end">
                            <a class="nav-link active" href="kirim_ekspor.php">
                            <button class="btn btn-primary">Ekspor Barang</button>
                            </a>
                    </div>
                    <svg class="bi bi-box-arrow-in-down" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" style=""></svg>Data Di Ekspor</h5></b>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive mt-2">
                            <?php
                            $result = $conn->query($sql);
                            ?>
                        <table class="table" id="dataTable">
                        <thead>
                        <tr>
                            <th>ID Ekspor</th>
                            <th>Negara Penerima</th>
                            <th>Tipe Barang</th>
                            <th>Nama Barang</th>
                            <th>Status</th>
                            <th>Tanggal Ekspor</th>
                            <th>Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $status_class = '';
                                $span_size = '';

                                if ($row['status'] == 'Permintaan Persetujuan') {
                                    $status_class = 'badge bg-warning text-dark';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Disetujui Importir') {
                                    $status_class = 'badge bg-primary';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Dikirimkan') {
                                    $status_class = 'badge bg-info';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Diterima') {
                                    $status_class = 'badge bg-success';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Dalam perjalanan') {
                                    $status_class = 'badge bg-secondary';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Ditolak Importir') {
                                    $status_class = 'badge bg-danger';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Gagal') {
                                    $status_class = 'badge bg-dark';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Dikembalikan') {
                                    $status_class = 'badge bg-secondary text-light';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Diverifikasi') {
                                    $status_class = 'badge bg-info text-light';
                                    $span_size = 'badge-lg';
                                } elseif ($row['status'] == 'Selesai') {
                                    $status_class = 'badge bg-success';
                                    $span_size = 'badge-lg';
                                }
                        ?>
                        <tr>
                            <td><?= $row['id_ekspor'] ?></td>
                            <td><?= $row['negara_penerima'] ?></td>
                            <td><?= $row['tipe_barang'] ?></td>
                            <td><?= $row['nama_barang'] ?></td>
                            <td><span class="<?= $status_class ?> <?= $span_size ?>"><?= $row['status'] ?></span></td>
                            <td><?= $row['tanggal_ekspor'] ?></td>
                            <td><a href='ekspor_detail.php?id_ekspor=<?= $row['id_ekspor'] ?>' class="btn btn-sm btn-primary">Detail</a></td>
                        </tr>
                        <?php
                        }
                        } else {
                            echo "<tr><td colspan='7'>Tidak ada data ekspor barang.</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                    </div>

                                    <div class="col-md-6"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           </div>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>