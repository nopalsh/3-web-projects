<?php
require_once "koneksi.php";
session_start();

if (!isset($_SESSION['id_pengguna'])) {
    header("Location: login.php");
    exit();
}

if(isset($_GET['id_ekspor']) && !empty($_GET['id_ekspor'])) {
    $id_ekspor = $_GET['id_ekspor'];
    $sql = "SELECT ekspor_barang.*,
            (SELECT negara FROM pengguna WHERE id_pengguna = ekspor_barang.negara_penerima) AS negara_penerima,
			(SELECT negara FROM pengguna WHERE id_pengguna = ekspor_barang.id_pengguna) AS negara_pengguna,
            detail_barang.*
            FROM ekspor_barang
            INNER JOIN detail_barang ON ekspor_barang.id_barang = detail_barang.id_barang
            WHERE ekspor_barang.id_ekspor = $id_ekspor";

    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_ekspor = $row['id_ekspor'];
        $nama_barang = $row['nama_barang'];
        $tipe_barang = $row['tipe_barang'];
        $jumlah = $row['jumlah'];
        $berat = $row['berat'];
        $deskripsi = $row['deskripsi'];
        $id_barang = $row['id_barang'];
        $id_pengguna = $row["negara_pengguna"];
        $negara_penerima = $row['negara_penerima'];
        $nama_penerima = $row['nama_penerima'];
        $alamat_penerima = $row['alamat_penerima'];
        $kode_pos_penerima = $row['kode_pos_penerima'];
        $status = $row['status'];
        $tanggal_ekspor = $row['tanggal_ekspor'];
        $nama_pengirim = $row['nama_pengirim'];
        $alamat_pengirim = $row['alamat_pengirim'];
        $kode_pos_pengirim = $row['kode_pos_pengirim'];
    } else {
        echo "Export data not found.";
    }
} else {
    echo "Invalid Export ID.";
}
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en" style="font-family: Poppins, sans-serif;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ekspedisi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/Navbar-Right-Links-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body id="page-top">
  <div id="wrapper" style="font-family: Poppins, sans-serif;">
    <div class="d-flex flex-column" id="content-wrapper" style="background: #f8f9fb;">
      <div id="wrapper">
        <nav class="navbar align-items-start sidebar accordion" style="background: #fff; border-right: 1px solid #eeeeee;">
          <div class="container-fluid d-flex flex-column p-0">
            <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
              <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-truck-loading" style="color: #142fb3;"></i>
              </div>
              <div class="sidebar-brand-text mx-3">
                <span style="color: #000000;">EKSPEDISI</span>
              </div>
            </a>
            <hr class="sidebar-divider my-0" />
            <ul id="accordionSidebar" class="navbar-nav text-light">
              <li class="nav-item">
                <a class="nav-link active" href="index.php">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -32 576 576" width="1em" height="1em" fill="currentColor" style="color: #6a6b83; position: relative; margin-top: -4px; margin-right: 8px;">
                    <path d="M511.8 287.6L512.5 447.7C512.5 450.5 512.3 453.1 512 455.8V472C512 494.1 494.1 512 472 512H456C454.9 512 453.8 511.1 452.7 511.9C451.3 511.1 449.9 512 448.5 512H392C369.9 512 352 494.1 352 472V384C352 366.3 337.7 352 320 352H256C238.3 352 224 366.3 224 384V472C224 494.1 206.1 512 184 512H128.1C126.6 512 125.1 511.9 123.6 511.8C122.4 511.9 121.2 512 120 512H104C81.91 512 64 494.1 64 472V360C64 359.1 64.03 358.1 64.09 357.2V287.6H32.05C14.02 287.6 0 273.5 0 255.5C0 246.5 3.004 238.5 10.01 231.5L266.4 8.016C273.4 1.002 281.4 0 288.4 0C295.4 0 303.4 2.004 309.5 7.014L416 100.7V64C416 46.33 430.3 32 448 32H480C497.7 32 512 46.33 512 64V185L564.8 231.5C572.8 238.5 576.9 246.5 575.8 255.5C575.8 273.5 560.8 287.6 543.8 287.6L511.8 287.6z"></path>
                  </svg>
                  <span style="color: #6a6b83;">
                    <span style="font-weight: normal !important;">Beranda</span>
                  </span>
                </a>
                <a class="nav-link active" href="impor.php">
                  <svg class="bi bi-box-arrow-in-down" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" style="color: #3f4d95; position: relative; margin-top: -8px; margin-right: 8px;">
                    <path fill-rule="evenodd" d="M3.5 6a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 1 0-1h2A1.5 1.5 0 0 1 14 6.5v8a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 14.5v-8A1.5 1.5 0 0 1 3.5 5h2a.5.5 0 0 1 0 1h-2z"></path>
                    <path fill-rule="evenodd" d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
                  </svg>
                  <span style="color: #6a6b83;">
                    <span style="font-weight: normal !important;">Data Impor</span>
                  </span>
                </a>
                <a class="nav-link active" href="ekspor.php" style="background: #dadcef;border-width: 10px;border-color: rgb(0,0,0);border-left: 5px solid #142fb3;">
                  <svg class="bi bi-box-arrow-in-up" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" style="color: #3f4d95; position: relative; margin-top: 0; margin-right: 8px;">
                    <path fill-rule="evenodd" d="M3.5 10a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 0 0 1h2A1.5 1.5 0 0 0 14 9.5v-8A1.5 1.5 0 0 0 12.5 0h-9A1.5 1.5 0 0 0 2 1.5v8A1.5 1.5 0 0 0 3.5 11h2a.5.5 0 0 0 0-1h-2z"></path>
                    <path fill-rule="evenodd" d="M7.646 4.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707V14.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708l3-3z"></path>
                  </svg>
                  <span style="color: #3f4d95;">Data Ekspor</span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
        <div class="container-fluid" style="padding: 0; margin: 0;">
          <nav class="navbar navbar-expand mb-4 topbar static-top navbar-light navbar-dark" style="background: #142fb3; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #eeeeee;">
            <div class="container-fluid">
              <form method="GET" action="" class="mb-4">
                <div class="row">
                  <p class="p-id">Detail Ekspor Barang #<td><?php echo $id_ekspor ?></td></p>
				    </label>
                </div>
            </form>
            <ul class="navbar-nav flex-nowrap ms-auto" style="margin: 0;">
                <div class="d-none d-sm-block topbar-divider"></div>
                    <li class="nav-item dropdown no-arrow">
                    <div class="nav-item dropdown no-arrow">
                    <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#" style="color: white;">
                    <?php
                    $id_pengguna = $_SESSION['id_pengguna'];
                    $query = "SELECT negara FROM pengguna WHERE id_pengguna = $id_pengguna";
                    $result = $conn->query($query);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $negara = $row['negara'];
                                echo "<span class='d-none d-lg-inline me-2 small'>$negara</span>";
                                }
                            }
                    ?>
                    <img class="border rounded-circle img-profile" src="https://t3.ftcdn.net/jpg/05/14/18/46/360_F_514184651_W5rVCabKKRH6H3mVb62jYWfuXio8c8si.jpg" />
                    </a>
                    <div class="dropdown-menu dropdown-menu-end animated--grow-in">
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php" style="color: black;">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>
                        Keluar </a>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</nav>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header py-3">
                    <p class="text-primary m-0 fw-bold">Detail Pengirim</p>
                </div>
				    <div class="card-body">
                    <div class="table-responsive table mt-2" id="dataTable-3" role="grid" aria-describedby="dataTable_info">
                        <table class="table">
                            <tbody>
                                <tr class="table-data">
                                    <td>Negara Pengirim</td>
                                    <td><?php echo $id_pengguna; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Nama Pengirim</td>
                                    <td><?php echo $nama_pengirim; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Alamat Pengirim</td>
                                    <td><?php echo $alamat_pengirim; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Kode Pos Pengirim</td>
                                    <td><?php echo $kode_pos_pengirim; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card mt-4">
                <div class="card-header py-3">
                    <p class="text-primary m-0 fw-bold">Detail Barang</p>
                </div>
				<div class="card-body">
                    <div class="table-responsive table mt-2" id="dataTable-1" role="grid" aria-describedby="dataTable_info">
                        <table class="table">
                            <tbody>
                                <tr class="table-data">
                                    <td>ID Barang</td>
                                    <td><?php echo $id_barang; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Nama Barang</td>
                                    <td><?php echo $nama_barang; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Tipe Barang</td>
                                    <td><?php echo $tipe_barang; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Jumlah</td>
                                    <td><?php echo $jumlah; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Berat</td>
                                    <td><?php echo $berat; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Deskripsi</td>
                                    <td><?php echo $deskripsi; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header py-3">
                    <p class="text-primary m-0 fw-bold">Detail Penerima</p>
                </div>
                <div class="card-body">
                    <div class="table-responsive table mt-2" id="dataTable-2" role="grid" aria-describedby="dataTable_info">
                        <table class="table">
                            <tbody>
                                <tr class="table-data">
                                    <td>Negara Penerima</td>
                                    <td><?php echo $id_pengguna; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Nama Penerima</td>
                                    <td><?php echo $nama_penerima; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Alamat Penerima</td>
                                    <td><?php echo $alamat_penerima; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Kode Pos Penerima</td>
                                    <td><?php echo $kode_pos_penerima; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card mt-4">
                <div class="card-header py-3">
                    <p class="text-primary m-0 fw-bold">Status</p>
                </div>
               <div class="card-body">
                    <div class="table-responsive table mt-2" id="dataTable-4" role="grid" aria-describedby="dataTable_info">
                        <table class="table">
                            <tbody>
                                <tr class="table-data">
                                    <td>Status</td>
                                    <td><?php echo $status; ?></td>
                                </tr>
                                <tr class="table-data">
                                    <td>Tanggal Ekspor</td>
                                    <td><?php echo $tanggal_ekspor; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="update-button">
                        <a href='edit_ekspor.php?id_ekspor=<?php echo $id_ekspor ?>' class="btn btn-sm btn-warning">Ubah Data</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
            <br/>
            </div>
            </div>
            </div>
            <a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
            </div>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/theme.js"></script>
    </body>
</html>