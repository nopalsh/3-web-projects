<?php
/*
    Hak Cipta © 2024 Mochamad Naufal Shofy
    Web ini telah dilesensikan
    Repository GitHub: https://github.com/nopalsh/3-web-projects
*/
$servername = "localhost";
$username = "root";
$password = "";
$database = "db_ekspedisi";
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
