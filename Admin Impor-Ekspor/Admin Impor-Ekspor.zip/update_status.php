<?php
require_once "koneksi.php";
session_start();

if (!isset($_SESSION['id_pengguna'])) {
    header("Location: login.php");
    exit();
}
$id_impor = $_GET['id_impor'];
$query_update_impor = "UPDATE impor_barang SET status = 'Disetujui Importir' WHERE id_impor = $id_impor";
mysqli_query($conn, $query_update_impor);
$query_update_ekspor = "UPDATE ekspor_barang SET status = 'Disetujui Importir' WHERE id_ekspor = $id_impor";
mysqli_query($conn, $query_update_ekspor);
$status_baru = 'Disetujui Importir';
$keterangan_baru = 'Barang telah disetujui importir';
$id_tracking = mt_rand(100000, 999999);
$query_insert_tracking = "INSERT INTO tracking_barang (id_tracking, id_pengguna, id_impor, id_ekspor, status_barang, keterangan, tanggal_update)
                          VALUES ('$id_tracking', '{$_SESSION['id_pengguna']}', '$id_impor', '$id_impor', '$status_baru', '$keterangan_baru', NOW())";
mysqli_query($conn, $query_insert_tracking);
$query_insert_timeline = "INSERT INTO history_timeline (id_tracking, status_barang, keterangan, tanggal_update)
                          VALUES ('$id_tracking', '$status_baru', '$keterangan_baru', NOW())";
mysqli_query($conn, $query_insert_timeline);
header("Location: impor.php");
exit();
?>

