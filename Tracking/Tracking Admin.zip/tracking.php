<?php
require_once "koneksi.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

$sql = "SELECT tracking_barang.*,
        (SELECT negara FROM pengguna WHERE id_pengguna = ekspor_barang.id_pengguna) AS negara_penerima,
        (SELECT negara FROM pengguna WHERE id_pengguna = impor_barang.id_pengguna) AS negara_pengirim,
        detail_barang.tipe_barang AS tipe_barang,
        detail_barang.nama_barang AS nama_barang
        FROM tracking_barang
        LEFT JOIN ekspor_barang ON tracking_barang.id_ekspor = ekspor_barang.id_ekspor
        LEFT JOIN impor_barang ON tracking_barang.id_impor = impor_barang.id_impor
        LEFT JOIN detail_barang ON impor_barang.id_barang = detail_barang.id_barang OR ekspor_barang.id_barang = detail_barang.id_barang";

if (isset($_GET['submit'])) {
    $filters = array();
    if (!empty($_GET['statusFilter'])) {
        $statusFilters = implode("','", $_GET['statusFilter']);
        $filters[] = "status_barang IN ('$statusFilters')";
    }
    if (!empty($_GET['countryFilter'])) {
        $countryFilters = implode("','", $_GET['countryFilter']);
        $filters[] = "negara_pengirim IN ('$countryFilters')";
    }
    if (!empty($_GET['yearFilter'])) {
        $yearFilter = $_GET['yearFilter'];
        $filters[] = "YEAR(tanggal_update) = '$yearFilter'";
    }
    if (!empty($_GET['monthFilter'])) {
        $monthFilter = $_GET['monthFilter'];
        $filters[] = "MONTH(tanggal_update) = '$monthFilter'";
    }
    if (!empty($filters)) {
        $sql .= " WHERE " . implode(" AND ", $filters);
    }
}
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en" style="font-family: Poppins, sans-serif;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Tracking</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="tracking.css">
</head>
<body id="page-top">
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container" style="font-family: Poppins, sans-serif;">
            <a class="navbar-brand" href="#">Tracking</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <b><a class="nav-link" href="tracking.php" style="border-bottom: 3px solid #fbd304;" >Tracking</a></b>
                    </li>
                </ul>
            </div>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <button class="btn btn-logout">Logout</button>
                </li>
            </ul>
        </div>
    </nav>
	<div class="content" style="font-family: Poppins, sans-serif;">
<div class="sidebar">
    <form action="" method="GET">
        <p class="filter-heading">Filter</p>
        <div class="menu">
            <ul>
                <li>
                    <li>
                        <label for="statusFilterImpor">Filter Status:</label>
                        <div class="filter-options">
                        <input type="checkbox" id="statusFilter1" name="statusFilter[]" value="Disetujui Importir">
                        <label for="statusFilter1">Disetujui</label><br>
                        <input type="checkbox" id="statusFilter2" name="statusFilter[]" value="Diproses">
                        <label for="statusFilter2">Diproses</label><br>
                        <input type="checkbox" id="statusFilter3" name="statusFilter[]" value="Dikirim">
                        <label for="statusFilter3">Dikirim</label><br>
                        <input type="checkbox" id="statusFilter4" name="statusFilter[]" value="Selesai">
                        <label for="statusFilter4">Selesai</label><br>
                        <input type="checkbox" id="statusFilter5" name="statusFilter[]" value="Tertunda">
                        <label for="statusFilter5">Tertunda</label><br>
                        <input type="checkbox" id="statusFilter6" name="statusFilter[]" value="Ditolak Importir">
                        <label for="statusFilter6">Ditolak</label><br>
                        <input type="checkbox" id="statusFilter7" name="statusFilter[]" value="Gagal">
                        <label for="statusFilter7">Gagal</label><br>
                        </div>
                 </li>
                <li>
                    <label for="countryFilter">Filter Negara Penerima :</label>
                    <div class="filter-options">
                        <?php
                        $countryQuery = "SELECT id_pengguna, negara FROM pengguna";
                        $countryResult = $conn->query($countryQuery);
                        if ($countryResult->num_rows > 0) {
                            while ($row = $countryResult->fetch_assoc()) {
                                $id = $row['id_pengguna'];
                                $country = $row['negara'];
                                echo "<input type='checkbox' id='countryFilter$id' name='countryFilter[]' value='$id'><label for='countryFilter$id'>$country</label><br>";
                            }
                        }
                        ?>
                    </div>
                    </li>
				<li>
                    <label for="monthFilterImpor">Filter Bulan:</label>
                    <select class="form-select" id="monthFilterImpor" name="monthFilter">
                    <option value="">Semua</option>
                    <option value="01">Januari</option>
                    <option value="02">Februari</option>
                    <option value="03">Maret</option>
                    <option value="04">April</option>
                    <option value="05">Mei</option>
                    <option value="06">Juni</option>
                    <option value="07">Juli</option>
                    <option value="08">Agustus</option>
                    <option value="09">September</option>
                    <option value="10">Oktober</option>
                    <option value="11">November</option>
                    <option value="12">Desember</option>
                    </select>
                </li>
                <li>
                    <label for="yearFilterImpor">Filter Tahun:</label>
                    <input type="number" class="form-control" id="yearFilterImpor" name="yearFilter" min="2000" max="2024" placeholder="Masukan Tahun">
                </li>
                <li>
                    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                </li>
            </ul>
        </div>
    </form>
        <div class="float-right mt-3">
        <a href="tambah_data_tracking.php" class="btn btn-primary">Tambah Data Tracking (Simulasi)</a>
    </div>
</div>
    <div class="header-card-container">
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Data Pengiriman</h5>
                <div class="table-responsive">
                    <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID Tracking</th>
                    <th scope="col">Negara Penerima</th>
                    <th scope="col">Negara Pengirim</th>
                    <th scope="col">Status</th>
                    <th scope="col">Tanggal Update</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id_tracking"] . "</td>";
                        echo "<td>" . $row["negara_penerima"] . "</td>";
                        echo "<td>" . $row["negara_pengirim"] . "</td>";
                        $status_class = '';
                        switch ($row["status_barang"]) {
                            case 'Disetujui Importir':
                                $status_class = 'badge bg-warning';
                                break;
                            case 'Diproses':
                                $status_class = 'badge bg-primary';
                                break;
                            case 'Dikirim':
                                $status_class = 'badge bg-info';
                                break;
                            case 'Tertunda':
                                $status_class = 'badge bg-warning';
                                break;
                            case 'Selesai':
                                $status_class = 'badge bg-success';
                                break;
                            case 'Ditolak Importir':
                                $status_class = 'badge bg-danger';
                                break;
                            case 'Gagal':
                                $status_class = 'badge bg-danger';
                                break;
                            default:
                                $status_class = 'badge bg-secondary';
                        }
                        echo "<td><span class='$status_class'>" . $row["status_barang"] . "</span></td>";
                        echo "<td>" . $row["tanggal_update"] . "</td>";
                        echo "<td>";
                        echo "<a href='status_tracking.php?id_tracking=" . $row["id_tracking"] . "' class='btn btn-warning btn-table'><i class='fas fa-edit'></i></a>";
                        echo "<a href='detail_kiriman.php?id_tracking=" . $row["id_tracking"] . "' class='btn btn-primary btn-table'><i class='fas fa-info-circle'></i></a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No tracking data found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        </div>
        </div>
    </div>

</div>
</div>
</div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/theme.js"></script>
</body>
</html>
