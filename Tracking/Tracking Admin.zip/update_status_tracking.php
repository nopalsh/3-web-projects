<?php
require_once "koneksi.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_tracking = $_POST['id_tracking'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];
    $sql = "UPDATE tracking_barang SET status_barang = '$status', keterangan = '$keterangan' WHERE id_tracking = $id_tracking";
    $sql2 = "INSERT INTO history_timeline (id_tracking, status_barang, keterangan, tanggal_update) VALUES ($id_tracking, '$status', '$keterangan', NOW())";

    if ($conn->query($sql) === TRUE && $conn->query($sql2) === TRUE) {
        header("Location: tracking.php?id_tracking=$id_tracking&success=1");
        exit();
    } else {
        header("Location: tracking.php?id_tracking=$id_tracking&error=1");
        exit();
    }
} else {
    header("Location: tracking.php");
    exit();
}
?>

