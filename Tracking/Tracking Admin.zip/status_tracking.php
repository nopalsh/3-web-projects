<?php
// Include database connection
require_once "koneksi.php";

// Check if id_tracking parameter is set
if (isset($_GET['id_tracking'])) {
    // Fetch the ID Tracking from the URL
    $id_tracking = $_GET['id_tracking'];

    // Fetch data related to the ID Tracking from the database
    $sql = "SELECT * FROM tracking_barang WHERE id_tracking = $id_tracking";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the row
        $row = $result->fetch_assoc();
    } else {
        // If no data found for the ID Tracking, handle this case accordingly
        echo "No data found for the ID Tracking";
        exit();
    }
} else {
    // If id_tracking parameter is not set, handle this case accordingly
    echo "ID Tracking parameter is missing";
    exit(); // Exit the script
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Tracking</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <!-- Card to display ID Tracking -->
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">ID Tracking #<?php echo $row['id_tracking']; ?></h5>
                    </div>
                </div>

                <!-- Card with form to update status -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Update Status</h5>
                        <form action="update_status_tracking.php" method="POST">
    <!-- Hidden field to pass id_tracking -->
    <input type="hidden" name="id_tracking" value="<?php echo $row['id_tracking']; ?>">

    <div class="form-group">
        <label for="status">Update Status:</label>
        <select class="form-control" id="status" name="status" onchange="updateKeterangan()">
            <option value="" style="font-style:italic">Pilih Status Barang</option>
            <option value="Disetujui Importir">Disetujui Importir</option>
            <option value="Diproses">Diproses</option>
            <option value="Dikirim">Dikirim</option>
            <option value="Selesai">Selesai</option>
            <option value="Tertunda">Tertunda</option>
            <option value="Gagal">Gagal</option>
            <option value="Ditolak Importir">Ditolak Importir</option>
        </select>
    </div>

    <div class="form-group">
        <label for="keterangan">Keterangan:</label>
        <input type="text" class="form-control" id="keterangan" name="keterangan">
    </div>
    
    <button type="submit" class="btn btn-primary">Update Status</button>
</form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    function updateKeterangan() {
        var status = document.getElementById('status').value;
        var keterangan = document.getElementById('keterangan');
        
        switch (status) {
            case 'Disetujui Importir':
                keterangan.value = 'Permohonan telah disetujui importir.';
                break;
            case 'Diproses':
                keterangan.value = 'Pesanan sedang diproses.';
                break;
            case 'Dikirim':
                keterangan.value = 'Pesanan telah dikirim.';
                break;
            case 'Selesai':
                keterangan.value = 'Pesanan telah selesai.';
                break;
            case 'Tertunda':
                keterangan.value = 'Pesanan tertunda, silakan cek kembali nanti.';
                break;
            case 'Gagal':
                keterangan.value = 'Pesanan gagal, silakan hubungi layanan pelanggan.';
                break;
            case 'Ditolak Importir':
                keterangan.value = 'Pesanan ditolak importir, silakan hubungi layanan pelanggan.';
                break;
            default:
                keterangan.value = '';
        }
    }
</script>
</body>

</html>
