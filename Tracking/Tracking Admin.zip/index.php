<?php
require_once "koneksi.php";
session_start();
if (!isset($_SESSION["id_pengguna"])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$query_tracking_count = "SELECT DATE_FORMAT(tanggal_update, '%Y-%m-%d') AS tanggal, COUNT(*) AS jumlah FROM tracking_barang GROUP BY DATE_FORMAT(tanggal_update, '%Y-%m-%d')";
$result_tracking_count = mysqli_query($conn, $query_tracking_count);
$dates = array();
$counts = array();

while ($row = mysqli_fetch_assoc($result_tracking_count)) {
    $dates[] = $row['tanggal'];
    $counts[] = $row['jumlah'];
}

$data = array(
    'dates' => $dates,
    'counts' => $counts
);

$query_status_count = "SELECT status_barang, COUNT(*) AS jumlah FROM tracking_barang GROUP BY status_barang";
$result_status_count = mysqli_query($conn, $query_status_count);
$status_count = array();
while ($row = mysqli_fetch_assoc($result_status_count)) {
    $status_count[$row['status_barang']] = $row['jumlah'];
}

$statuses = ['Disetujui', 'Diproses', 'Dikirim', 'Selesai', 'Tertunda', 'Gagal'];

foreach ($statuses as $status) {
    $status_count[$status] = $status_count[$status] ?? 0;
}
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en" style="font-family: Poppins, sans-serif;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Tracking</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="tracking.css">
</head>

<body id="page-top">
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container" style="font-family: Poppins, sans-serif;">
            <a class="navbar-brand" href="#">Tracking</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <b><a class="nav-link" href="index.php" style="border-bottom: 3px solid #fbd304;">Beranda</a></b>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tracking.php" >Tracking</a>
                    </li>
                </ul>
            </div>
            <form method="post" class="d-flex">
                <button class="btn btn-logout" name="logout" type="submit">Logout</button>
            </form>
        </div>
    </nav>
<div class="container">
  <div class="row">
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #1cc88a;">Disetujui</div>
                        <div class="text-dark fw-bold h5 mb-0"><?php echo $status_count['Disetujui']; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-check-circle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #4e73df;">Diproses</div>
                        <div class="text-dark fw-bold h5 mb-0"><?php echo $status_count['Diproses']; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-cogs fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #e74a3b;">Gagal</div>
                        <div class="text-dark fw-bold h5 mb-0"><?php echo $status_count['Dikirim']; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-times-circle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #f6c23e;">Selesai</div>
                        <div class="text-dark fw-bold h5 mb-0"><?php echo $status_count['Selesai']; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-check-circle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #f6c23e;">Tertunda</div>
                        <div class="text-dark fw-bold h5 mb-0"><?php echo $status_count['Tertunda']; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-check-circle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #f6c23e;">Gagal</div>
                        <div class="text-dark fw-bold h5 mb-0"><?php echo $status_count['Gagal']; ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-check-circle fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
	<div class="container mt-4">
    <div class="row row-cols-md-2">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Tren Waktu</h5>
                    <canvas id="lineChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Distribusi Status</h5>
                    <canvas id="donutChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/theme.js"></script>
	<script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
	<script>
        var data = {
            labels: <?php echo json_encode($data['dates']); ?>,
            datasets: [{
                label: 'Jumlah Tracking',
                data: <?php echo json_encode($data['counts']); ?>,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                fill: false
            }]
        };
        var options = {
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'day'
                    }
                },
                y: {
                    beginAtZero: true
                }
            }
        };
        var ctx = document.getElementById('lineChart').getContext('2d');
        var lineChart = new Chart(ctx, {
            type: 'line',
            data: data,
            options: options
        });
    </script>
<script>
    var ctx = document.getElementById('donutChart').getContext('2d');
    var donutChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($statuses); ?>,
            datasets: [{
                label: 'Status',
                data: <?php echo json_encode(array_values($status_count)); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 159, 64, 0.6)',
                    'rgba(0, 255, 0, 0.6)',
					'rgba(255, 0, 0, 0.6)',
                    'rgba(0, 0, 255, 0.6)',
                    'rgba(128, 128, 128, 0.6)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 159, 64, 0.6)',
                    'rgba(0, 255, 0, 0.6)',
					'rgba(255, 0, 0, 0.6)',
                    'rgba(0, 0, 255, 0.6)',
                    'rgba(128, 128, 128, 0.6)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            plugins: {
                legend: {
                    position: 'right',
                },
                title: {
                    display: true,
                    text: 'Status Barang'
                }
            }
        }
    });
</script>
</body>
</html>