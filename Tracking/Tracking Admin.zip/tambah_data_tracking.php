<?php
require_once "koneksi.php";
session_start();
if (!isset($_SESSION['id_pengguna'])) {
    header("Location: login.php");
    exit();
}
$id_pengguna = $_SESSION['id_pengguna'];
$sql_pengguna = "SELECT id_pengguna, negara FROM pengguna";
$result_pengguna = $conn->query($sql_pengguna);
$user_pengguna = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_barang = $_POST['nama_barang'];
    $tipe_barang = $_POST['tipe_barang'];
    $jumlah = $_POST['jumlah'];
    $berat = $_POST['berat'];
    $deskripsi = $_POST['deskripsi'];
    $negara_tujuan = $_POST['negara_tujuan'];
    $nama_penerima = $_POST['nama_penerima'];
    $alamat_penerima = $_POST['alamat_penerima'];
    $kode_pos_penerima = $_POST['kode_pos_penerima'];
    $nama_pengirim = $_POST['nama_pengirim'];
    $alamat_pengirim = $_POST['alamat_pengirim'];
    $kode_pos_pengirim = $_POST['kode_pos_pengirim'];
    $id_impor = mt_rand(100000, 999999);
    $id_ekspor = $id_impor;
    $sql_insert_detail = "INSERT INTO detail_barang (nama_barang, tipe_barang, jumlah, berat, deskripsi)
                          VALUES ('$nama_barang', '$tipe_barang', '$jumlah', '$berat', '$deskripsi')";
    if ($conn->query($sql_insert_detail) === TRUE) {
        $id_barang = $conn->insert_id;
        $sql_insert_impor = "INSERT INTO impor_barang (id_impor, id_barang, id_pengguna, negara_pengirim, nama_penerima, alamat_penerima, kode_pos_penerima, nama_pengirim, alamat_pengirim, kode_pos_pengirim )
                             VALUES ('$id_impor', '$id_barang', '$negara_tujuan', '$id_pengguna', '$nama_penerima', '$alamat_penerima', '$kode_pos_penerima', '$nama_pengirim', '$alamat_pengirim', '$kode_pos_pengirim')";
        if ($conn->query($sql_insert_impor) === TRUE) {
            $sql_insert_ekspor = "INSERT INTO ekspor_barang (id_ekspor, id_barang, negara_penerima, nama_pengirim, alamat_pengirim, kode_pos_pengirim, id_pengguna, nama_penerima, alamat_penerima, kode_pos_penerima)
                                  VALUES ('$id_ekspor', '$id_barang', '$negara_tujuan', '$nama_pengirim', '$alamat_pengirim', '$kode_pos_pengirim', '$id_pengguna', '$nama_penerima', '$alamat_penerima', '$kode_pos_penerima')";
            if ($conn->query($sql_insert_ekspor) === TRUE) {
                $query_update_impor = "UPDATE impor_barang SET status = 'Disetujui Importir' WHERE id_impor = $id_impor";
                mysqli_query($conn, $query_update_impor);
                $query_update_ekspor = "UPDATE ekspor_barang SET status = 'Disetujui Importir' WHERE id_ekspor = $id_impor";
                mysqli_query($conn, $query_update_ekspor);
                $status_baru = 'Disetujui Importir';
                $keterangan_baru = 'Barang telah disetujui importir';
                $id_tracking = mt_rand(100000, 999999);
                $query_insert_tracking = "INSERT INTO tracking_barang (id_tracking, id_pengguna, id_impor, id_ekspor, status_barang, keterangan, tanggal_update)
                                          VALUES ('$id_tracking', '{$_SESSION['id_pengguna']}', '$id_impor', '$id_impor', '$status_baru', '$keterangan_baru', NOW())";
                mysqli_query($conn, $query_insert_tracking);
                $query_insert_timeline = "INSERT INTO history_timeline (id_tracking, status_barang, keterangan, tanggal_update)
                                          VALUES ('$id_tracking', '$status_baru', '$keterangan_baru', NOW())";
                mysqli_query($conn, $query_insert_timeline);
                header("Location: index.php");
                exit();
            } else {
                echo "Error: " . $sql_insert_ekspor . "<br>" . $conn->error;
            }
        } else {
            echo "Error: " . $sql_insert_impor . "<br>" . $conn->error;
        }
    } else {
        echo "Error: " . $sql_insert_detail . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en" style="font-family: Poppins, sans-serif;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ekspedisi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/Navbar-Right-Links-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body id="page-top">
    <div id="wrapper" style="font-family: Poppins, sans-serif;">
        <div class="d-flex flex-column" id="content-wrapper" style="background: #f8f9fb;">
            <div id="wrapper">

                <div class="container-fluid" style="padding: 0; margin: 0;">
                    <nav class="navbar navbar-expand mb-4 topbar static-top navbar-light navbar-dark"
                        style="background: #2c3454; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #eeeeee;">
                        <div class="container-fluid">
                                 <form method="GET" action="" class="mb-4">
                                <div class="row">
										<p class="p-id">Tambah Data Untuk Tracking</td></p>
										</label>
                                </div>
                            </form>
                        </div>
                    </nav>
                <div class="container-fluid">
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="card mt-4">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Isi Data Barang</p>
                        </div>
                        <div class="card-body">
                            <table class="table my-0">
                         <tbody>
                                <tr>
                                    <td><strong>Nama Barang</strong></td>
                                    <td><input class="form-control" type="text" name="nama_barang"></td>
                                </tr>
                                <tr>
                                    <td><strong>Tipe Barang</strong></td>
                                    <td><input class="form-control" type="text" name="tipe_barang"></td>
                                </tr>
                                <tr>
                                    <td><strong>Jumlah</strong></td>
                                    <td><input class="form-control" type="text" name="jumlah"></td>
                                </tr>
                                <tr>
                                    <td><strong>Berat</strong></td>
                                    <td><input class="form-control" type="text" name="berat"></td>
                                </tr>
                                <tr>
                                    <td><strong>Deskripsi</strong></td>
                                    <td><input class="form-control" type="text" name="deskripsi"></td>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card mt-4">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Mau Kirim Kemana? Ke Siapa?</p>
                        </div>
                        <div class="card-body">
                            <table class="table my-0">
                                <tbody>
                                    <tr>
                                        <td><strong>Negara Penerima</strong></td>
                                        <td>
                                            <select class="form-control" name="negara_tujuan" required>
                                                <option value="">Pilih Negara Tujuan</option>
                                                <?php
                                                if ($result_pengguna->num_rows > 0) {
                                                    while ($row_pengguna = $result_pengguna->fetch_assoc()) {
                                                        echo "<option value='" . $row_pengguna['id_pengguna'] . "'>" . $row_pengguna['negara'] . "</option>";
                                                    }
                                                } else {
                                                    echo "<option value=''>Tidak ada pengguna tersedia</option>";
                                                }
                                                ?>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Nama Penerima</strong></td>
                                        <td><input class="form-control" type="text" name="nama_penerima"></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Alamat Penerima</strong></td>
                                        <td><input class="form-control" type="text" name="alamat_penerima"></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Kode Pos Penerima</strong></td>
                                        <td><input class="form-control" type="text" name="kode_pos_penerima"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card mt-4">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 fw-bold">Masukan Data Pengirim</p>
                        </div>
                        <div class="card-body">
                            <table class="table my-0">
                                <tbody>
                                    <tr>
                                        <td><strong>Nama Pengirim</strong></td>
                                        <td><input class="form-control" type="text" name="nama_pengirim"></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Alamat Pengirim</strong></td>
                                        <td><input class="form-control" type="text" name="alamat_pengirim"></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Kode Pos Pengirim</strong></td>
                                        <td><input class="form-control" type="text" name="kode_pos_pengirim"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="mt-4">
                        <input class="btn btn-primary" type="submit" value="Submit">
                    </div>
                </form>
				<br/>
				<br/>
            </div>
        </div>
    </div>
</div>
<a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
</div>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/theme.js"></script>
</body>
</html>