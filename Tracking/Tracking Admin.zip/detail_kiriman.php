<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ekspedisi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="tracking.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container" style="font-family: Poppins, sans-serif;">
            <a class="navbar-brand" href="#">Tracking</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <b><a class="nav-link" href="tracking.php" style="border-bottom: 3px solid #fbd304;" >Tracking</a></b>
                    </li>
                </ul>
            </div>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <button class="btn btn-logout">Logout</button>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div>
            <div style="height: 32px;width: 3px;position: absolute;border-left-style: solid;border-left-color: rgb(60,149,236);"></div>
            <h3 style="margin-top: 24px;margin-bottom: 24px;margin-left: 10px; color: black;">Detail Kiriman</h3>
        </div>
        <?php
        require_once "koneksi.php";
        if (isset($_GET['id_tracking'])) {
            $id_tracking = $_GET['id_tracking'];
            $sql = "SELECT tracking_barang.*, impor_barang.*, ekspor_barang.*, detail_barang.*,
            (SELECT negara FROM pengguna WHERE id_pengguna = ekspor_barang.negara_penerima) AS negara_penerima,
            (SELECT negara FROM pengguna WHERE id_pengguna = impor_barang.negara_pengirim) AS negara_pengirim
            FROM tracking_barang
            LEFT JOIN impor_barang ON tracking_barang.id_impor = impor_barang.id_impor
            LEFT JOIN ekspor_barang ON tracking_barang.id_ekspor = ekspor_barang.id_ekspor
            LEFT JOIN detail_barang ON (impor_barang.id_barang = detail_barang.id_barang OR ekspor_barang.id_barang = detail_barang.id_barang)
            WHERE tracking_barang.id_tracking = $id_tracking";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        ?>
            <div class="row">
            <div class="col-md-12">
            <div class="card">
            <div class="card-body">
                 <h5 class="card-title">Detail Barang</h5>
                <table class="table">
                    <tbody>
                        <tr>
                            <td><strong>Nama Barang</strong></td>
                            <td><?php echo $row['nama_barang']; ?></td>
                        </tr>
                        <tr>
                            <td><strong>Tipe Barang</strong></td>
                            <td><?php echo $row['tipe_barang']; ?></td>
                        </tr>
                        <tr>
                            <td><strong>Jumlah</strong></td>
                            <td><?php echo $row['jumlah']; ?></td>
                        </tr>
                        <tr>
                            <td><strong>Berat</strong></td>
                            <td><?php echo $row['berat']; ?></td>
                        </tr>
                        <tr>
                            <td><strong>Deskripsi</strong></td>
                            <td><?php echo $row['deskripsi']; ?></td>
                        </tr>
                    </tbody>
                </table>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Informasi Pengirim</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Negara Pengirim</strong></td>
                        <td><?php echo $row['negara_pengirim']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Pengirim</strong></td>
                        <td><?php echo $row['nama_pengirim']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat Pengirim</strong></td>
                        <td><?php echo $row['alamat_pengirim']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Kode Pos Pengirim</strong></td>
                        <td><?php echo $row['kode_pos_pengirim']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Informasi Penerima</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Negara Penerima</strong></td>
                        <td><?php echo $row['negara_penerima']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Penerima</strong></td>
                        <td><?php echo $row['nama_penerima']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat Penerima</strong></td>
                        <td><?php echo $row['alamat_penerima']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Kode Pos Penerima</strong></td>
                        <td><?php echo $row['kode_pos_penerima']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Status Pengiriman</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td><?php echo $row['status_barang']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal Impor</strong></td>
                        <td><?php echo $row['tanggal_impor']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
	<?php
	} else {
    echo "<tr><td colspan='2'>No tracking data found</td></tr>";
    }
    } else {
    echo "<tr><td colspan='2'>ID Tracking parameter is missing</td></tr>";
    }
    ?>
    </div>
    <br/>
    <br/>
    <br/>
        </div>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>