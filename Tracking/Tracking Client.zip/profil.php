<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Kinlong</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
    <link rel="stylesheet" href="assets/css/Footer-Dark-icons.css">
</head>

<body>
    <nav class="navbar navbar-expand-md fixed-top navbar-shrink py-3 navbar-light" id="mainNav">
        <div class="container"><a class="navbar-brand d-flex align-items-center" href="/"><span>Kinlong Hardware Indonesia</span></a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Beranda</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"><a class="nav-link active" href="profil.php">Profil</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="py-5 mt-5" style="/*margin-top: 0px;*/">
        <div class="container py-4 py-xl-5" style="margin-top: -50px;">
            <div class="row gy-4 gy-md-0">
                <div class="col-md-6 text-center text-md-start d-flex d-sm-flex d-md-flex justify-content-center align-items-center justify-content-md-start align-items-md-center justify-content-xl-center">
                    <div style="max-width:350px;">
                        <h1 class="display-5 fw-bold mb-4">Tentang Kami</h1>
                        <p class="text-muted my-4">PT Kinlong Hardware Indonesia adalah penyedia terkemuka dalam industri hardware dan aksesori bangunan. Kami memiliki komitmen untuk memberikan solusi logistik terbaik dan layanan pengiriman yang handal untuk memenuhi kebutuhan bisnis Anda.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div><img class="rounded img-fluid w-100 fit-cover" style="min-height: 300px;" src="assets/img/illustrations/kl-1.jpg"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">
        <div class="container py-5" style="margin-top: -200px;">
            <div class="row row-cols-1 row-cols-md-2 mx-auto" style="max-width: 900px;">
                <div class="col mb-5"><img class="rounded img-fluid" src="assets/img/illustrations/kl-2.jpg"></div>
                <div class="col d-md-flex align-items-md-end align-items-lg-center mb-5">
                    <div>
                        <h5 class="fs-3 fw-bold mb-4">Komitmen Kami</h5>
                        <p class="text-muted mb-4">Kami bertekad untuk memberikan layanan pengiriman yang terbaik kepada pelanggan kami. Dengan tim profesional dan sistem yang terintegrasi, kami siap memberikan solusi logistik yang handal dan efisien untuk mendukung pertumbuhan bisnis Anda.</p>
                    </div>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-2 mx-auto" style="max-width: 900px;">
                <div class="col order-md-last mb-5"><img class="rounded img-fluid" src="assets/img/illustrations/kl-3.jpg"></div>
                <div class="col d-md-flex align-items-md-end align-items-lg-center mb-5">
                    <div class="ms-md-3">
                        <h5 class="fs-3 fw-bold mb-4"><strong>Pengalaman dan Keahlian</strong></h5>
                        <p class="text-muted mb-4">Dengan pengalaman bertahun-tahun dalam industri logistik, kami telah memperoleh keahlian dan pengetahuan yang mendalam dalam mengelola pengiriman barang dengan efisien dan tepat waktu. Tim kami siap memberikan layanan yang terbaik untuk memenuhi kebutuhan pengiriman Anda.</p>
                    </div>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-2 mx-auto" style="max-width: 900px;">
                <div class="col mb-5"><img class="rounded img-fluid" src="assets/img/illustrations/kl-4.jpg"></div>
                <div class="col d-md-flex align-items-md-end align-items-lg-center mb-5">
                    <div>
                        <h5 class="fs-3 fw-bold mb-4"><strong>Komitmen pada Kualitas</strong></h5>
                        <p class="text-muted mb-4">Kami mengutamakan kualitas dalam setiap aspek layanan kami, mulai dari pengemasan barang hingga pengiriman akhir. Dengan standar yang ketat dan pengawasan yang ketat, kami memastikan bahwa setiap pengiriman dilakukan dengan keamanan dan ketepatan yang tinggi.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="text-center bg-dark">
        <div class="container text-white py-4 py-lg-5">
            <p class="text-muted mb-0"><span style="color: rgba(255, 255, 255, 0.75);">Copyright © 2024 Kinlong Hardware Indonesia</span></p>
        </div>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/startup-modern.js"></script>
</body>

</html>