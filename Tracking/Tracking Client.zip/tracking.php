<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Kinlong</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
	<link rel="stylesheet" href="timeline.css">
</head>

<body>
    <nav class="navbar navbar-expand-md fixed-top navbar-shrink py-3 navbar-light" id="mainNav">
        <div class="container"><a class="navbar-brand d-flex align-items-center" href="/"><span>Kinlong Hardware Indonesia</span></a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Beranda</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"><a class="nav-link" href="profil.php">Profil</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"></li>
                </ul>
            </div>
        </div>
    </nav>
   
    <section></section>
    <section></section>
    <section>
        <div class="container py-4 py-xl-5">
             <?php
                            // Include database connection
                            require_once "koneksi.php";

                            // Check if id_tracking exists in the database
                            $sql = "SELECT id_tracking FROM tracking_barang WHERE id_tracking = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("s", $_GET['id_tracking']);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows === 0) {
                                echo "<script>alert('Data tidak ditemukan');</script>";
                                echo "<script>location='index.php';</script>";
                                exit;
                            }

                            // Check if id_tracking parameter is set
                            if (isset($_GET['id_tracking'])) {
                                $id_tracking = $_GET['id_tracking'];

                                // Fetch detailed tracking data from database
                                $sql = "SELECT tracking_barang.*, impor_barang.*, ekspor_barang.*, detail_barang.*,
								(SELECT negara FROM pengguna WHERE id_pengguna = ekspor_barang.negara_penerima) AS negara_penerima,
								(SELECT negara FROM pengguna WHERE id_pengguna = impor_barang.negara_pengirim) AS negara_pengirim
								FROM tracking_barang 
								LEFT JOIN impor_barang ON tracking_barang.id_impor = impor_barang.id_impor 
								LEFT JOIN ekspor_barang ON tracking_barang.id_ekspor = ekspor_barang.id_ekspor 
								LEFT JOIN detail_barang ON (impor_barang.id_barang = detail_barang.id_barang OR ekspor_barang.id_barang = detail_barang.id_barang) 
								WHERE tracking_barang.id_tracking = $id_tracking";
                                $result = $conn->query($sql);

                                // Display tracking data
                                if ($result->num_rows > 0) {
                                    $row = $result->fetch_assoc(); 
									?>
		<div class="row">
		
<div class="col-md-12">
	<br/>
	<br/>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Status Pengiriman</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td><?php echo $row['status_barang']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal Impor</strong></td>
                        <td><?php echo $row['tanggal_impor']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-md-12">
	<br/>
	<br/>
    <div class="card">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h6 class="card-title">Timeline</h6>
                <div id="content">
                    <ul class="timeline">
                        <?php
                        // Fetch timeline data from the database
                        $timeline_sql = "SELECT tanggal_update, status_barang, keterangan FROM history_timeline WHERE id_tracking = $id_tracking ORDER BY tanggal_update DESC";
                        $timeline_result = $conn->query($timeline_sql);

                        if ($timeline_result->num_rows > 0) {
                            while ($timeline_row = $timeline_result->fetch_assoc()) {
                                $tanggal_update = $timeline_row['tanggal_update'];
                                $status_terbaru = $timeline_row['status_barang'];
                                $deskripsi_status_terbaru = $timeline_row['keterangan'];
                                ?>
                                <li class="event" data-date="<?php echo $tanggal_update; ?>">
                                    <h3><?php echo $status_terbaru; ?></h3>
                                    <p><?php echo $deskripsi_status_terbaru; ?></p>
                                </li>
                            <?php
                            }
                        } else {
                            echo "<li class='event'>No timeline data found</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
            <div class="col-md-12">
				<br/>
	<br/>
    <div class="card">

        <div class="card-body">
            <h5 class="card-title">Detail Barang</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Nama Barang</strong></td>
                        <td><?php echo $row['nama_barang']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tipe Barang</strong></td>
                        <td><?php echo $row['tipe_barang']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Jumlah</strong></td>
                        <td><?php echo $row['jumlah']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Berat</strong></td>
                        <td><?php echo $row['berat']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Deskripsi</strong></td>
                        <td><?php echo $row['deskripsi']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-md-12">
	<br/>
	<br/>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Informasi Pengirim</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Negara Pengirim</strong></td>
                        <td><?php echo $row['negara_pengirim']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Pengirim</strong></td>
                        <td><?php echo $row['nama_pengirim']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat Pengirim</strong></td>
                        <td><?php echo $row['alamat_pengirim']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Kode Pos Pengirim</strong></td>
                        <td><?php echo $row['kode_pos_pengirim']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-md-12">
	<br/>
	<br/>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Informasi Penerima</h5>
            <table class="table">
                <tbody>
                    <tr>
                        <td><strong>Negara Penerima</strong></td>
                        <td><?php echo $row['negara_penerima']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Penerima</strong></td>
                        <td><?php echo $row['nama_penerima']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat Penerima</strong></td>
                        <td><?php echo $row['alamat_penerima']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Kode Pos Penerima</strong></td>
                        <td><?php echo $row['kode_pos_penerima']; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>




			<?php
			} else {
                                    echo "<tr><td colspan='2'>No tracking data found</td></tr>";
                                }
                            } else {
                                echo "<tr><td colspan='2'>ID Tracking parameter is missing</td></tr>";
                            }
                            ?>
        </div>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/startup-modern.js"></script>
</body>

</html>
