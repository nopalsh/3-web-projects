<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Kinlong</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
    <link rel="stylesheet" href="assets/css/Footer-Dark-icons.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
</head>

<body>
    <nav class="navbar navbar-expand-md fixed-top navbar-shrink py-3 navbar-light" id="mainNav">
        <div class="container"><a class="navbar-brand d-flex align-items-center" href="/"><span>Kinlong Hardware Indonesia</span></a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Beranda</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"><a class="nav-link" href="profil.php">Profil</a></li>
                    <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"></li>
                </ul>
            </div>
        </div>
    </nav>
    <header class="pt-5">
        <div class="container pt-4 pt-xl-5">
            <div class="row pt-5">
                <div class="col-md-8 text-center text-md-start mx-auto">
                    <div class="text-center">
                        <h1 class="display-4 fw-bold mb-5">Layanan Pengiriman Kinlong<span class="underline"> Hardware</span>.</h1>
                        <p class="fs-5 text-muted mb-5">Temukan solusi pengiriman terbaik untuk kebutuhan Anda.</p>
                        <form class="d-flex justify-content-center flex-wrap" method="get" data-bs-theme="light" action="tracking.php">
                            <div class="shadow-lg mb-3"><input class="form-control form-control" type="text" name="id_tracking" placeholder="Masukkan ID Tracking"></div>
                            <div class="shadow-lg mb-3"><button class="btn btn-primary" type="submit">Submit</button></div>
                        </form>
                    </div>
                </div>
                <div class="col-12 col-lg-10 mx-auto">
                    <div class="text-center position-relative"></div>
                </div>
            </div>
        </div>
    </header>
    <section>
        <div class="container py-4 py-xl-5">
            <div class="row gy-4 row-cols-1 row-cols-md-2 row-cols-lg-3">
                <div class="col">
                    <div class="card border-light border-1 d-flex justify-content-center p-4">
                        <div class="card-body">
                            <div class="d-flex flex-shrink-0 justify-content-center align-items-center bs-icon-lg bs-icon-rounded bs-icon-secondary d-inline-block mb-4 bs-icon">
                            <i class="fas fa-box"></i>
                            </div>
                            <div>
                                <h4 class="fw-bold">Produk Unggulan</h4>
                                <p class="text-muted">Temukan berbagai produk unggulan dari Kinlong Hardware Indonesia untuk kebutuhan pembangunan dan perbaikan Anda.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-light border-1 d-flex justify-content-center p-4">
                        <div class="card-body">
                            <div class="d-flex flex-shrink-0 justify-content-center align-items-center bs-icon-lg bs-icon-rounded bs-icon-secondary d-inline-block mb-4 bs-icon">
                            <i class="fas fa-handshake"></i>

                            </div>
                            <div>
                                <h4 class="fw-bold">Layanan Unggulan</h4>
                                <p class="text-muted">Nikmati layanan pengiriman barang terbaik dengan jaringan luas Kinlong Hardware Indonesia.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-light border-1 d-flex justify-content-center p-4">
                        <div class="card-body">
                            <div class="d-flex flex-shrink-0 justify-content-center align-items-center bs-icon-lg bs-icon-rounded bs-icon-secondary d-inline-block mb-4 bs-icon">
                            <i class="fas fa-sync-alt"></i>

                            </div>
                            <div>
                                <h4 class="fw-bold">Pembaruan Terkini</h4>
                                <p class="text-muted">Ikuti berita terbaru seputar produk dan layanan Kinlong Hardware Indonesia.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container py-4 py-xl-5">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="display-6 fw-bold pb-md-4">Solusi Terbaik untuk Bisnis Anda <span class="underline">di Sini</span></h3>
                </div>
                <div class="col-md-6 pt-4">
                    <p class="text-muted mb-4">Temukan beragam solusi pengiriman barang yang tepat untuk memenuhi kebutuhan bisnis Anda. Kami siap membantu Anda mengembangkan bisnis Anda lebih jauh.</p>
                </div>
            </div>
            <div class="row gy-4 gy-md-0">
                <div class="col-md-6 d-flex d-sm-flex d-md-flex justify-content-center align-items-center justify-content-md-start align-items-md-center justify-content-xl-center">
                    <div>
                        <div class="row gy-2 row-cols-1 row-cols-sm-2">
                            <div class="col text-center text-md-start">
                                <div class="d-flex justify-content-center align-items-center justify-content-md-start"><svg class="icon icon-tabler icon-tabler-sun fs-3 text-primary bg-secondary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"></path>
                        <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path>
                    </svg>
                                    <h5 class="fw-bold mb-0 ms-2">Jasa Pengiriman</h5>
                                </div>
                                <p class="text-muted my-3">Kami menyediakan layanan pengiriman barang yang handal dan efisien untuk memenuhi kebutuhan pengiriman Anda.</p>
                            </div>
                            <div class="col text-center text-md-start">
                                <div class="d-flex justify-content-center align-items-center justify-content-md-start"><svg class="icon icon-tabler icon-tabler-sun fs-3 text-primary bg-secondary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"></path>
                        <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path>
                    </svg>
                                    <h5 class="fw-bold mb-0 ms-2">Logistik Terpadu</h5>
                                </div>
                                <p class="text-muted my-3">Kami menawarkan solusi logistik terpadu untuk memudahkan pengiriman barang Anda ke seluruh destinasi.</p>
                            </div>
                            <div class="col text-center text-md-start">
                                <div class="d-flex justify-content-center align-items-center justify-content-md-start"><svg class="icon icon-tabler icon-tabler-sun fs-3 text-primary bg-secondary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"></path>
                        <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path>
                    </svg>
                                    <h5 class="fw-bold mb-0 ms-2">Ekspor &amp; Impor</h5>
                                </div>
                                <p class="text-muted my-3">Kami menyediakan layanan ekspor dan impor untuk memperluas jangkauan pasar Anda secara internasional.</p>
                            </div>
                            <div class="col text-center text-md-start">
                                <div class="d-flex justify-content-center align-items-center justify-content-md-start"><svg class="icon icon-tabler icon-tabler-sun fs-3 text-primary bg-secondary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"></path>
                        <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path>
                    </svg>
                                    <h5 class="fw-bold mb-0 ms-2">Pelayanan Unggul</h5>
                                </div>
                                <p class="text-muted my-3">Kami berkomitmen untuk memberikan pelayanan terbaik dan solusi logistik yang tepat untuk kebutuhan bisnis Anda.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 order-first order-md-last">
                    <div><img class="rounded img-fluid w-100 fit-cover" style="min-height:300px;" src="assets/img/illustrations/kl-building.jpg"></div>
                </div>
            </div>
        </div>
    </section>
    <section></section>
    <footer class="text-center bg-dark">
        <div class="container text-white py-4 py-lg-5">
            <p class="text-muted mb-0"><span style="color: rgba(255, 255, 255, 0.75);">Copyright © 2024 Kinlong Hardware Indonesia</span></p>
        </div>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/startup-modern.js"></script>
</body>

</html>