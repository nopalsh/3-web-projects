<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Kinlong</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark-icons.css">
</head>

<body>
    <nav class="navbar navbar-expand-md fixed-top navbar-shrink py-3 navbar-light" id="mainNav">
        <div class="container"><a class="navbar-brand d-flex align-items-center" href="/"><span>Kinlong Hardware Indonesia</span></a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Beranda</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"><a class="nav-link" href="profil.php">Profil</a></li>
                    <li class="nav-item"><a class="nav-link active" href="kontak.php">Kontak</a></li>
                    <li class="nav-item"></li>
                    <li class="nav-item"></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="py-5 mt-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-md-8 col-xl-6 text-center mx-auto">
                    <h2 class="display-6 fw-bold mb-4">Hubungi <span class="underline">Kami</span></h2>
                    <p class="text-muted">Jika Anda memiliki pertanyaan atau membutuhkan bantuan lebih lanjut, jangan ragu untuk menghubungi kami. Tim kami siap membantu Anda dengan layanan yang ramah dan responsif.</p>
                </div>
            </div>
            <div class="row d-flex justify-content-center">
                <div class="col-md-8 col-lg-6 text-center">
                    <div>
                        <table class="table table-borderless text-muted">
                            <tbody>
                                <tr>
                                    <td><i class="fas fa-building fa-2x me-2"></i></td>
                                    <td>PT Kinlong Hardware Indonesia</td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-map-marker-alt fa-2x me-2"></i></td>
                                    <td>Jl. Contoh No. 123, Jakarta, Indonesia</td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-envelope fa-2x me-2"></i></td>
                                    <td><a class="text-muted" href="mailto:info@kinlong.co.id">info@kinlong.co.id</a></td>
                                </tr>
                                <tr>
                                    <td><i class="fas fa-phone-alt fa-2x me-2"></i></td>
                                    <td>+62 123 456 789</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="text-center bg-dark">
        <div class="container text-white py-4 py-lg-5">
            <p class="text-muted mb-0"><span style="color: rgba(255, 255, 255, 0.75);">Copyright © 2024 Kinlong Hardware Indonesia</span></p>
        </div>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/startup-modern.js"></script>
</body>

</html>